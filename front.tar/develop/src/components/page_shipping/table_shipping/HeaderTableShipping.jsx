import React from 'react';
import PropTypes from 'prop-types';
import 'semantic-ui-css/semantic.min.css';
import { connect } from 'react-redux';

import { InputSearch } from '../../common';
import '../../page_orders/table_orders/TableOrders.css';
import '../../../styles/Panel.css';

const styles = {
  header: 'table-orders__cell_head table-orders__cell',
  headerFirst: 'table-orders__cell_head table-orders__cell table-orders__column_first',
  search: 'table-orders__search-bar ',
  checkbox: 'table-orders__checkbox',
  button: 'table-orders__button',
  buttonContainer: 'table-orders__input-container',
  input: 'table-orders__input',
  inputContainer: 'table-orders__input-container',
};

const mapStateToProps = ({ orderSearch }) => ({
  itemInfo: orderSearch.itemInfo,
  customer: orderSearch.customer,
  orderID: orderSearch.orderID,
  itemID: orderSearch.itemID,
});

class HeaderTableShipping extends React.PureComponent {
  makeSearchSubmitter = field => ({ target }) => this.props.changeSearch({
    [field]: target.value,
  });
  render() {
    return (
      <tr>
        <th className={styles.header}>
          <div className={styles.search}>
            <InputSearch
              placeHolder="OrderID..."
              styles={styles}
              value={this.props.orderID}
              submit={this.makeSearchSubmitter('orderID')}
            />
            <InputSearch
              placeHolder="Buyers Info..."
              styles={styles}
              value={this.props.customer}
              submit={this.makeSearchSubmitter('customer')}
            />
            <InputSearch
              placeHolder="Item Info..."
              styles={styles}
              value={this.props.itemInfo}
              submit={this.makeSearchSubmitter('itemInfo')}
            />
            <InputSearch
              placeHolder="Item ID..."
              styles={styles}
              value={this.props.itemID}
              submit={this.makeSearchSubmitter('itemID')}
            />
            <div className={styles.buttonContainer}/>
          </div>
        </th>
      </tr>
    );
  }
}

HeaderTableShipping.propTypes = {
  itemInfo: PropTypes.string,
  customer: PropTypes.string,
  orderID: PropTypes.string,
  itemID: PropTypes.string,
  changeSearch: PropTypes.func,
};

HeaderTableShipping.defaultProps = {
  itemInfo: '',
  customer: '',
  orderID: '',
  itemID: '',
  changeSearch: changes => {},
};


export default connect(mapStateToProps)(HeaderTableShipping);
