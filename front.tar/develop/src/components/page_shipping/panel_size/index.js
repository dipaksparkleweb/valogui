export { default } from './PanelSize';
