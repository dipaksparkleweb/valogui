import { call } from 'redux-saga/effects';
import { getResponseStatus } from '../../services/helpers';

export default function* failureSaga({ error }) {
  yield call([console, 'error'], error);
  // const errorJson = yield call([JSON, 'stringify'], error);
  // yield call([console, 'log'], errorJson);
  // yield call([console, 'log'], getError({ error }));
};
