import { put, call } from 'redux-saga/effects';

export default updateActionCreator => function* makeSagaChangePageAndCall () {
  yield put(updateActionCreator());
};
