import { put, call } from 'redux-saga/effects';

export default changePageActionCreator => function* makeSagaChangeLimitAndCall() {
  yield put(changePageActionCreator(1));
};
