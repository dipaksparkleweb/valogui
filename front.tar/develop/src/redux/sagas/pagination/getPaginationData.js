export default (params, { limit, offset }) => ({
  offset: params ? 0 : offset,
  limit,
});