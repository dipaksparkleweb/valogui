import qz from 'qz-tray';
import RSVP from 'rsvp';
import { createHash } from 'crypto';
import { call } from 'redux-saga/effects';

import { prepareZPL } from '../../../services/helpers';

qz.api.setPromiseType(resolver => new RSVP.Promise(resolver));
qz.api.setSha256Type(data => createHash('sha256').update(data).digest('hex'));

export function printZplQz(b64EncodedFile) {
  const config = qz.configs.create('Zebra');
  return qz.print(config, prepareZPL(b64EncodedFile));
}

export function printPdfQz(b64EncodedFile) {
  const config = qz.configs.create('Zebra');
  return qz.print(config, [{
    type: 'pdf',
    format: 'base64',
    data: b64EncodedFile,
  }]);
}

export function* connectToQzTray(){
  if (!qz.websocket.isActive()) yield call([qz.websocket, 'connect']);
  yield call([qz.printers, 'find'], 'zebra');
}

export function* connectAndPrintZPL(b64EncodedFile) {
  yield call(connectToQzTray);
  yield call(printZplQz, b64EncodedFile);
}

export function* connectAndPrintPDF(b64EncodedFile) {
  yield call(connectToQzTray);
  yield call(printPdfQz, b64EncodedFile);
}