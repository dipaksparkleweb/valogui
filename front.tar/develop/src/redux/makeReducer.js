const makeReducer = (initialState, actionHandelers) => (state = initialState, action) => {
  if (actionHandelers[action.type])
    return actionHandelers[action.type](state, action);
  return state;
};

export default makeReducer;