

export const getOffset = ({ limit, count, offset }, { page }) => {
  if (!page) return offset;
  if (count / limit >= page) return (page - 1) * limit;
  return Math.floor(count / limit) * limit;
};
