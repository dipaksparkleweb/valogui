import TableShipping from '../components/page_shipping/table_shipping/TableShipping';
import { PaginationShipping } from '../components/page_shipping';
import HeaderOrderSearch from '../components/page_orders/header_order_search/HeaderOrderSearch';
import TableWrapperWithHeader from '../components/layout/table_wrapper/TableWrapperWithHeader';

export default TableWrapperWithHeader(TableShipping, PaginationShipping, HeaderOrderSearch);
