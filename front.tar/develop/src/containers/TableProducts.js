import TableProducts from '../components/page_products/table_products/TableProducts';
import PaginationProducts from '../components/page_products/pagination_products/PaginationProducts';
import TableWrapperWithHeader from '../components/layout/table_wrapper/TableWrapperWithHeader';
import HeaderProducts from '../components/page_products/header_products/HeaderProducts';

export default TableWrapperWithHeader(TableProducts, PaginationProducts, HeaderProducts);
