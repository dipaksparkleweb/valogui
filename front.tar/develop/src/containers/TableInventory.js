import TableInventory from '../components/page_inventory/table_inventory/TableInventory';
import PaginationInventory from '../components/page_inventory/pagination_inventory/PaginationInventory';
import HeaderInventory from '../components/page_inventory/header_inventory/HeaderInventory';
import TableWrapperWithHeader from '../components/layout/table_wrapper/TableWrapperWithHeader';

export default TableWrapperWithHeader(TableInventory, PaginationInventory, HeaderInventory);