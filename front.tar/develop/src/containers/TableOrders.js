import TableOrders from '../components/page_orders/table_orders/TableOrders';
import PaginationOrders from '../components/page_orders/pagination_orders/PaginationOrders';
import HeaderOrderSearch from '../components/page_orders/header_order_search/HeaderOrderSearch';
import TableWrapperWithHeader from '../components/layout/table_wrapper/TableWrapperWithHeader';

export default TableWrapperWithHeader(TableOrders, PaginationOrders, HeaderOrderSearch);
