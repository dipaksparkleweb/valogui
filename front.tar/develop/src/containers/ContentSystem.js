import ContentSystem from '../components/page_system/content_system/ContentSystem';
import HeaderSystem from '../components/page_system/header_system/HeaderSystem';
import ContentWrapper from '../components/layout/table_wrapper/ContentWrapper';

export default ContentWrapper(ContentSystem, HeaderSystem);
