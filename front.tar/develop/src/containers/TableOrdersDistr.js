import TableOrders from '../components/page_orders/table_orders/TableOrders';
import PaginationOrders from '../components/page_orders/pagination_orders/PaginationOrders';
import HeaderDistr from '../components/page_distr/header_distr/HeaderDistr';
import TableWrapperWithHeader from '../components/layout/table_wrapper/TableWrapperWithHeader';

export default TableWrapperWithHeader(TableOrders, PaginationOrders, HeaderDistr);