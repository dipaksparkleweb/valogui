export { default as PageForbidden } from './page_forbidden/PageForbidden';
export { default as PageInventory } from './page_inventory/PageInventory';
export { default as PageOrders } from './page_orders/PageOrders';
export { default as PageDistr } from './page_distr/PageDistr';
export { default as PageShipping } from './page_shipping/PageShipping';
export { default as PageSystem } from './page_system/PageSystem';
export { default as PageProducts } from './page_products/PageProducts';
export { default as PageNotFound } from './page_not_found/PageNotFound';
export { default as PageLogin } from './page_login/LoginPageContainer';
export { default as PagePrintLabel } from './page_print_label/PagePrintLabel';

