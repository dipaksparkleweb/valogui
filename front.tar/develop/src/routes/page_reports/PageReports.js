import React, { Component } from 'react';
import PropTypes from 'prop-types';

class PageReports extends Component {
  render() {
    return (
      <div></div>
    );
  }
}

PageReports.propTypes = {};
PageReports.defaultProps = {};

export default withPermissionRedirection(PageReports);