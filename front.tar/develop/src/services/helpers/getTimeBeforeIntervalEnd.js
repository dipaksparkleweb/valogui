export default interval => interval - (Date.now() % interval);
