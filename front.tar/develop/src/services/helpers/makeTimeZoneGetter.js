import moment from 'moment-timezone';

export default function makeTimeZoneGetter(timeZone, format) {
  return () => moment().tz(timeZone).format(format);
}