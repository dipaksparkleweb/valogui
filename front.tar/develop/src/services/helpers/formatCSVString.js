import CSVNullToSpace from './CSVNullToSpace';

export default csvString => CSVNullToSpace(csvString)
  .split(',').join(' ')
  .split('"').join('""');