export default function searchToObj(query) {
  if (query){
    return query
      .slice(1).split('&').map(exp => exp.split('='))
      .reduce((obj, pair) => ({ ...obj, [pair[0]]:pair[1] }), {});
  }
  return null;
}
