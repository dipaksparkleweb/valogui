export default function isoDateToMonthSlashDay(isoDate) {
  if (!isoDate) return isoDate;
  let dateTime = isoDate.split('T');
  if (dateTime.length === 1) dateTime = isoDate.split(' ');
  return dateTime[0]
    .split('-')
    .slice(1,3)
    .join('/');
}