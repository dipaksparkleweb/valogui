export default function shortenString(str, length) {
  if (str && length && str.length > length) {
    return `${str.slice(0, length - 1)}...`;
  }
  return str;
}