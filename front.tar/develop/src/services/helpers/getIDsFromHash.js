const getIDsFromHash = (hash) => {
  const fields = hash.split('/');
  return { orderID: fields[0], orderItemID: fields[1], marketplaceID: +fields[2] };
};

export default getIDsFromHash;
