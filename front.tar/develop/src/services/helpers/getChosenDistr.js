const getChosenDistr = ({ list, choice }) => {
  const chosen = list.find(distr => distr.id === choice);
  return chosen || {};
};

export default getChosenDistr;
