const makeCountryNameCheck = countryNames => country =>
  countryNames.some(sample => country.toLowerCase() === sample);

export default makeCountryNameCheck;

