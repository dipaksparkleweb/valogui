import { changeOrder } from '../../redux/actions';

const makeOrderSubmitMaker = (dispatch, ids) => (field, loaderId) => value =>
  dispatch(changeOrder(ids, { [field]: value }, loaderId));

export default makeOrderSubmitMaker