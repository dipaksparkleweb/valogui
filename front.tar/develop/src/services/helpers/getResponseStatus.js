export default function getResponseStatus(error) {
  if (error && error.response) return error.response.status;
  return 0;
}