import makeTimeZoneGetter from './makeTimeZoneGetter';

export default makeTimeZoneGetter('America/New_York', 'YYYY-MM-DDTHH:mm');