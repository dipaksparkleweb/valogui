const reGF = /\^GFB,.+?,.+?,.+?,/;

const reZplCmd = /[\^~][A-Z][A-Z]?/g;


const putBackCmds = cmds => (arg, i) => (cmds[i] || '') + (arg || '');

const separateCommands = (zpl) => zpl
  .split(reZplCmd).slice(1)
  .map(putBackCmds(zpl.match(reZplCmd)));

const getZplImageObj = data => ({
  type: 'image',
  format: 'base64',
  options: { language: 'ZPL' },
  data,
});

const zplAsB64 = data => ({
  type: 'raw',
  format: 'base64',
  data,
});

const prepareBytes = (zpl, command) => {
  const found = command.match(reGF);
  if (found && found.length > 0) {
    const gf = found[0];
    const bytes = command.slice(gf.length+found.index);
    return [...zpl, getZplImageObj(bytes)];
  }
  return [...zpl, command];
};

const prepareZPL = zpl => separateCommands(zpl).reduce(prepareBytes, []);

// export default prepareZPL;

export default zpl => [ zplAsB64(zpl) ];