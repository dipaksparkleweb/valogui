import moment from 'moment-timezone';

export default (date, days) => moment(date).add(days, 'days').format('YYYY-MM-DD');