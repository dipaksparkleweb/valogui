export default function poke (value, label='') {
  console.log(label ? `${label}: ` : '', value);
  return value;
};