import getField from './getField';

export default (fieldName, obj, def) => getField(obj, fieldName) || def[fieldName];