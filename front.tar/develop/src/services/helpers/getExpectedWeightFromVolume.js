const getExpectedWeightFromVolume = ({ width, length, height }, density) => width * length * height * density;

export default getExpectedWeightFromVolume;
