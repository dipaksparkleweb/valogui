const rateTags = {
  shipping: 'shipping',
  returning: 'returning',
};

export default rateTags;