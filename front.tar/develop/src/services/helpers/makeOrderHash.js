const makeOrderHash = ({ orderID, orderItemID, marketplaceID }) =>
  `${orderID}/${orderItemID}/${marketplaceID}`;

export default makeOrderHash;