export default function objToSearch(obj) {
  const params = Object.keys(obj).map(key => `${key}=${obj[key]}`).join('&');
  return `?${params}`;
};