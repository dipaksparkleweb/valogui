export default function getNumberSeparated(num) {
  let numStr = num.toFixed(0);
  const triplets = [];
  while (numStr.length > 3) {
    triplets.unshift(numStr.slice(-3));
    numStr = numStr.slice(0, -3);
  }
  if (numStr) triplets.unshift(numStr);
  return triplets.join(',');
};