export default (obj, field) => {
  const { [field]:removed, ...filtered } = obj;
  return filtered;
};