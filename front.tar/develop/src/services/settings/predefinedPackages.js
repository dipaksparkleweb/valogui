const predefinedPackageNames = {
  regionalRateBoxA: 'RegionalRateBoxA',
  regionalRateBoxB: 'RegionalRateBoxB',
  flatRateEnvelope: 'FlatRateEnvelope',
  flatRateLegalEnvelope: 'FlatRateLegalEnvelope',
  flatRatePaddedEnvelope: 'FlatRatePaddedEnvelope',
  smallFlatRateBox: 'SmallFlatRateBox',
  mediumFlatRateBox: 'MediumFlatRateBox',
  largeFlatRateBox: 'LargeFlatRateBox',
  largeFlatRateBoardGameBox: 'LargeFlatRateBoardGameBox',
};

// Priority: NA
// Predefined Package: FlatRateEnvelope
// MIN Weight: 0.99 lb
// MAX Weight: 69.99 lbs
// MAX Dimensions: All dimensions must be "-" or 0
//
// Priority: NA
// Predefined Package: FlatRateLegalEnvelope
// MIN Weight: 0.99 lb
// MAX Weight: 69.99 lbs
// MAX Dimensions: All dimensions must be "-" or 0
//
// Priority: NA
// Predefined Package: FlatRatePaddedEnvelope
// MIN Weight: 0.99 lb
// MAX Weight: 69.99 lbs
// MAX Dimensions: All dimensions must be "-" or 0
//
// REGIONAL RATE CRITERIA:
//   Priority: 1
// Predefined Package: RegionalRateBoxA
// MIN Weight: 0.99 lb
// MAX Weight: 14.99 lbs
// MAX Dimensions: 10 x 7 x 5 -- or -- 16 x 11 x 2.5
//
// Priority: 2
// Predefined Package: RegionalRateBoxB
// MIN Weight: 0.99 lb
// MAX Weight: 19.99 lbs
// MAX Dimensions: 12 x 10.5 x 5.5 -- or -- 16 x 14.5 x 3
//
// FLAT RATE BOX CRITERIA:
//   Priority: 1
// Predefined Package: SmallFlatRateBox
// MIN Weight: 0.99 lb
// MAX Weight: 69.99 lbs
// MAX Dimensions: 8.6 x 5.3 x 1.6
//
// Priority: 2
// Predefined Package: MediumFlatRateBox
// MIN Weight: 0.99 lb
// MAX Weight: 69.99 lbs
// MAX Dimensions: 11 x 8.5 x 5.5
//
// Priority: 3
// Predefined Package: LargeFlatRateBox
// MIN Weight: 0.99 lb
// MAX Weight: 69.99 lbs
// MAX Dimensions: 12 x 12 x 5.5
//
// Priority: 4
// Predefined Package: LargeFlatRateBoardGameBox
// MIN Weight: 0.99 lb
// MAX Weight: 69.99 lbs
// MAX Dimensions: 24 x 11.5 x 3