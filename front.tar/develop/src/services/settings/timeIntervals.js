const timeIntervals = { second: 1000 };
timeIntervals.minute = 60 * timeIntervals.second;
timeIntervals.hour = 60 * timeIntervals.minute;

export default timeIntervals;
